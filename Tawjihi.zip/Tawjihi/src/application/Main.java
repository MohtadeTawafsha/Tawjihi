package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {
	private boolean isGaza;
	private boolean isScience;
	private Alert error = new Alert(AlertType.ERROR);
	private Alert succes = new Alert(AlertType.INFORMATION);
	private LinkedList<Tawjihi> westBankScience = new LinkedList<>();
	private LinkedList<Tawjihi> westBankLiterary = new LinkedList<>();
	private LinkedList<Tawjihi> gazaScience = new LinkedList<>();
	private LinkedList<Tawjihi> gazaLiterary = new LinkedList<>();

	@Override
	public void start(Stage stage) {
		read();
		stage.setTitle("Tawjihi");
		stage.getIcons().add(new Image("icon.png"));
		interface1(stage);
		stage.show();

	}

	private void read() {
		try {
			File myObj = new File("C:\\Users\\coolnet\\OneDrive\\سطح المكتب\\Project1\\Gaza_2022.csv");
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				String[] arr = data.split(",");
				if (arr[1].compareTo("Literary") == 0)
					gazaLiterary.addSort(new Tawjihi(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2])));
				else
					gazaScience.addSort(new Tawjihi(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2])));

			}
			myReader.close();
		} catch (FileNotFoundException e) {
			error.setContentText("An error occurred.");
			error.show();
		}

		try {
			File myObj = new File("C:\\Users\\coolnet\\OneDrive\\سطح المكتب\\Project1\\WestBank_2022.csv");
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				String[] arr = data.split(",");
				if (arr[1].compareTo("Literary") == 0)
					westBankLiterary.addSort(new Tawjihi(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2])));
				else
					westBankScience.addSort(new Tawjihi(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2])));
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			error.setContentText("An error occurred.");
			error.show();
		}

	}

	public void scienceOrLiterary(Stage stage) {
		GridPane paneWestBank = new GridPane();

		Text text = new Text("  Choose your branch");
		Font myFont = new Font("certuty gothic", 40);
		text.setFont(myFont);
		text.setFill(Color.GOLD);

		Button btScience = new Button("Science");
		btScience.setFont(new Font(40));
		btScience.setMinSize(400, 100);
		custmize(btScience);

		btScience.setOnAction(e -> {
			isScience = true;
			options(stage);
		});

		Button btLiterary = new Button("Literary");
		btLiterary.setFont(new Font(40));
		btLiterary.setMinSize(400, 100);
		custmize(btLiterary);

		btLiterary.setOnAction(e -> {
			isScience = false;
			options(stage);
		});

		Button btBack = new Button("Back");
		btBack.setFont(new Font(40));
		btBack.setMinSize(400, 100);
		custmize(btBack);

		btBack.setOnAction(e -> {
			interface1(stage);
		});

		paneWestBank.add(text, 0, 0);
		paneWestBank.add(btScience, 0, 1);
		paneWestBank.add(btLiterary, 0, 2);
		paneWestBank.add(btBack, 0, 4);

		paneWestBank.setAlignment(Pos.CENTER);
		paneWestBank.setHgap(10);
		paneWestBank.setVgap(10);

		setBackground(paneWestBank);
		Scene sceneWestBank = new Scene(paneWestBank, 1200, 700);
		stage.setScene(sceneWestBank);

	}

	public void options(Stage stage) {
		GridPane paneOptions = new GridPane();
		paneOptions.setHgap(10);
		paneOptions.setVgap(10);
		paneOptions.setAlignment(Pos.CENTER);

		VBox vBoxText = new VBox(10);
		vBoxText.setAlignment(Pos.TOP_CENTER);

		Text text = new Text("  Options Interface");
		Font myFont = new Font("certuty gothic", 40);
		text.setFont(myFont);
		text.setFill(Color.GOLD);
		vBoxText.getChildren().add(text);

		Button btAdd = new Button("Add Student");
		btAdd.setFont(new Font(40));
		btAdd.setMinSize(400, 100);
		vBoxText.getChildren().add(btAdd);
		vBoxText.getChildren().add(paneOptions);
		custmize(btAdd);

		btAdd.setOnAction(e -> addStudent(stage));

		Button btDelete = new Button("Delete Student");
		btDelete.setFont(new Font(40));
		btDelete.setMinSize(400, 100);
		custmize(btDelete);

		btDelete.setOnAction(e -> deleteStudent(stage));

		Button btSearch = new Button("Search Student");
		btSearch.setFont(new Font(40));
		btSearch.setMinSize(400, 100);
		custmize(btSearch);

		btSearch.setOnAction(e -> searchStudent(stage));

		paneOptions.addRow(0, btSearch, btDelete);

		Button btTop10 = new Button("Top ten Students");
		btTop10.setFont(new Font(40));
		btTop10.setMinSize(400, 100);
		custmize(btTop10);

		btTop10.setOnAction(e -> topTenStudent(stage));

		Button btMean = new Button("Mean Student");
		btMean.setFont(new Font(40));
		btMean.setMinSize(400, 100);
		custmize(btMean);

		btMean.setOnAction(e -> meanStudent(stage));

		paneOptions.addRow(1, btTop10, btMean);

		Button btMode = new Button("Mode Student");
		btMode.setFont(new Font(40));
		btMode.setMinSize(400, 100);
		custmize(btMode);

		btMode.setOnAction(e -> modeStudent(stage));

		Button btPercentage = new Button("Percentage above a Grade");
		btPercentage.setFont(new Font(30));
		btPercentage.setMinSize(400, 100);
		custmize(btPercentage);

		btPercentage.setOnAction(e -> percentageOfStudents(stage));

		paneOptions.addRow(2, btPercentage, btMode);

		Button btBack = new Button("Back");
		btBack.setFont(new Font(40));
		btBack.setMinSize(400, 100);
		custmize(btBack);

		vBoxText.getChildren().add(btBack);

		btBack.setOnAction(e -> scienceOrLiterary(stage));
		setBackground(vBoxText);
		Scene sceneScience = new Scene(vBoxText, 1200, 700);
		stage.setScene(sceneScience);
	}

	public void interface1(Stage stage) {
		GridPane paneFace = new GridPane();

		Text text = new Text("  Choose your region");
		Font myFont = new Font("certuty gothic", 40);
		text.setFont(myFont);
		text.setFill(Color.GOLD);

		Button btWestBank = new Button("West Bank");
		custmize(btWestBank);
		btWestBank.setFont(new Font(40));
		btWestBank.setMinSize(400, 100);

		btWestBank.setOnAction(e -> {
			isGaza = false;
			scienceOrLiterary(stage);
		});

		Button btGaza = new Button("Gaza");
		custmize(btGaza);
		btGaza.setFont(new Font(40));
		btGaza.setMinSize(400, 100);

		btGaza.setOnAction(e -> {
			isGaza = true;
			scienceOrLiterary(stage);
		});

		Button btClose = new Button("Close System");
		btClose.setFont(new Font(40));
		btClose.setMinSize(400, 100);
		custmize(btClose);

		btClose.setOnAction(e -> {
			stage.close();
		});

		paneFace.add(text, 0, 0);
		paneFace.add(btWestBank, 0, 1);
		paneFace.add(btGaza, 0, 2);
		paneFace.add(btClose, 0, 3);

		paneFace.setAlignment(Pos.CENTER);
		paneFace.setHgap(10);
		paneFace.setVgap(10);

		setBackground(paneFace);

		Scene sceneFace = new Scene(paneFace, 1200, 700);
		stage.setScene(sceneFace);

	}

	public void addStudent(Stage stage) {
		GridPane paneAddStudent = new GridPane();

		paneAddStudent.setAlignment(Pos.CENTER);
		paneAddStudent.setHgap(20);
		paneAddStudent.setVgap(20);

		Label lbSeat = new Label("Seat Number:");
		paneAddStudent.add(lbSeat, 0, 0);
		setLabelColor(lbSeat);

		TextField txtSeat = new TextField();
		paneAddStudent.add(txtSeat, 1, 0);
		textFieldCustom(txtSeat);

		Label lbAverage = new Label("Average:");
		paneAddStudent.add(lbAverage, 0, 1);
		setLabelColor(lbAverage);

		TextField txtAverage = new TextField();
		paneAddStudent.add(txtAverage, 1, 1);
		textFieldCustom(txtAverage);

		Button btAdd = new Button("Add");
		btAdd.setMinSize(80, 40);
		btAdd.setFont(new Font(20));
		paneAddStudent.add(btAdd, 1, 3);
		custmize(btAdd);

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		paneAddStudent.add(btBack, 0, 3);
		custmize(btBack);

		GridPane.setHalignment(btAdd, HPos.RIGHT);
		GridPane.setHalignment(btBack, HPos.CENTER);
		setBackground(paneAddStudent);
		Scene sceneAddStudent = new Scene(paneAddStudent, 1200, 700);
		stage.setScene(sceneAddStudent);

		btAdd.setOnAction(e -> {
			try {
				if (isGaza) {
					if (isScience)
						gazaScience.addSort(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Scientific",
								Double.parseDouble(txtAverage.getText())));
					else
						gazaLiterary.addSort(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Literary",
								Double.parseDouble(txtAverage.getText())));
				} else {
					if (isScience)
						westBankScience.addSort(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Scientific",
								Double.parseDouble(txtAverage.getText())));

					else
						westBankLiterary.addSort(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Literary",
								Double.parseDouble(txtAverage.getText())));
				}
			} catch (NumberFormatException e1) {
				error.setContentText("You must Integer and double!!!!!");
				error.show();
			}
		});

		btBack.setOnAction(e -> {
			options(stage);
		});

	}

	public void deleteStudent(Stage stage) {
		GridPane paneDeleteStudent = new GridPane();

		paneDeleteStudent.setAlignment(Pos.CENTER);
		paneDeleteStudent.setHgap(20);
		paneDeleteStudent.setVgap(20);

		Label lbSeat = new Label("Seat Number:");
		paneDeleteStudent.add(lbSeat, 0, 0);
		setLabelColor(lbSeat);

		TextField txtSeat = new TextField();
		paneDeleteStudent.add(txtSeat, 1, 0);
		textFieldCustom(txtSeat);

		Button btDelete = new Button("Delete");
		btDelete.setMinSize(80, 40);
		btDelete.setFont(new Font(20));
		paneDeleteStudent.add(btDelete, 1, 3);
		custmize(btDelete);

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		paneDeleteStudent.add(btBack, 0, 3);
		custmize(btBack);

		GridPane.setHalignment(btDelete, HPos.RIGHT);
		GridPane.setHalignment(btBack, HPos.CENTER);
		setBackground(paneDeleteStudent);
		Scene sceneDeleteStudent = new Scene(paneDeleteStudent, 1200, 700);
		stage.setScene(sceneDeleteStudent);

		btDelete.setOnAction(e -> {
			try {
				if (isGaza) {
					if (isScience)
						if (gazaScience.remove(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Scientific", 0))) {
							succes.setContentText("Deleted !");
							succes.show();
						} else {
							error.setContentText("USER NOT EXIT!!!!!");
							error.show();
						}
				} else if (gazaLiterary.remove(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Literary", 0))) {
					succes.setContentText("Deleted !");
					succes.show();
				} else {
					if (isScience) {
						if (westBankScience.remove(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Scientific", 0))) {
							succes.setContentText("Deleted !");
							succes.show();
						} else {
							error.setContentText("USER NOT EXIT!!!!!");
							error.show();
						}
					} else if (westBankLiterary
							.remove(new Tawjihi(Integer.parseInt(txtSeat.getText()), "Literary", 0))) {
						succes.setContentText("Deleted !");
						succes.show();
					} else {
						error.setContentText("USER NOT EXIT!!!!!");
						error.show();
					}
				}
			} catch (NumberFormatException e1) {
				error.setContentText("You must Integer and double!!!!!");
				error.show();
			}
		});

		btBack.setOnAction(e ->

		{

			options(stage);
		});

	}

	public void topTenStudent(Stage stage) {
		VBox vBoxTop = new VBox(30);
		vBoxTop.setAlignment(Pos.CENTER);

		Text textTop = new Text("Top 10 Students According to the Grade");
		Font myFont = new Font("certuty gothic", 40);
		textTop.setFont(myFont);
		textTop.setFill(Color.GOLD);

		GridPane panetxtArea = new GridPane();
		panetxtArea.setAlignment(Pos.CENTER);
		panetxtArea.setHgap(10);
		panetxtArea.setVgap(10);

		TextArea txtAreaTop = new TextArea();
		panetxtArea.add(txtAreaTop, 0, 0);

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		custmize(btBack);

		vBoxTop.getChildren().addAll(textTop, panetxtArea, btBack);

		if (isGaza) {
			if (isScience)
				txtAreaTop.setText(top10(gazaScience) + "");
			else
				txtAreaTop.setText(top10(gazaLiterary) + "");

		} else {
			if (isScience)
				txtAreaTop.setText(top10(westBankScience) + "");

			else
				txtAreaTop.setText(top10(westBankLiterary) + "");

		}

		btBack.setOnAction(e -> options(stage));

		setBackground(vBoxTop);
		Scene sceneTopTen = new Scene(vBoxTop, 1200, 700);
		stage.setScene(sceneTopTen);

	}

	// In order to put the first ten student in the first LinkedList ,
	// not taking into account the repetition by average , Time comp >> O(n)
	public LinkedList<Tawjihi> top10(LinkedList<Tawjihi> list) {
		Node<Tawjihi> prev = null;
		Node<Tawjihi> curr = list.getFront();
		LinkedList<Tawjihi> l = new LinkedList<>();

		int count = 1;

		while (count < 10 && curr != null) {
			if (prev != null && prev.getElement().getAverage() != curr.getElement().getAverage())
				count++;

			l.addLast(curr.getElement());

			prev = curr;
			curr = curr.getNext();
		}

		return l;
	}

	public void meanStudent(Stage stage) {
		VBox vBoxMean = new VBox(30);
		vBoxMean.setAlignment(Pos.CENTER);

		Text textMean = new Text("Mean Student");
		Font myFont = new Font("certuty gothic", 50);
		textMean.setFont(myFont);
		textMean.setFill(Color.GOLD);

		GridPane panetxt = new GridPane();
		panetxt.setAlignment(Pos.CENTER);
		panetxt.setHgap(10);
		panetxt.setVgap(10);

		TextField txtMean = new TextField();
		panetxt.add(txtMean, 0, 0);

		if (isGaza) {
			if (isScience)
				txtMean.setText(calculateAVG(gazaScience) + "");
			else
				txtMean.setText(calculateAVG(gazaLiterary) + "");

		} else {
			if (isScience)
				txtMean.setText(calculateAVG(westBankScience) + "");

			else
				txtMean.setText(calculateAVG(westBankLiterary) + "");

		}

		Button btBack = new Button("Back");
		btBack.setFont(new Font(20));
		btBack.setMinSize(80, 40);
		custmize(btBack);

		vBoxMean.getChildren().addAll(textMean, panetxt, btBack);

		btBack.setOnAction(e -> options(stage));

		setBackground(vBoxMean);
		Scene sceneTopMean = new Scene(vBoxMean, 1200, 700);
		stage.setScene(sceneTopMean);
	}

	// The function to calculate average , Time comp >> O(n)
	private String calculateAVG(LinkedList<Tawjihi> list) {
		Node<Tawjihi> curr = list.getFront();
		double sum = 0;
		while (curr != null) {
			sum += curr.getElement().getAverage();
			curr = curr.getNext();
		}

		if (sum == 0) {
			error.setContentText("You don't have users !");
			error.show();
			return "0";
		}
		return String.format("%.2f", sum / list.length());
	}

	public void modeStudent(Stage stage) {
		VBox vBoxMode = new VBox(30);
		vBoxMode.setAlignment(Pos.CENTER);

		Text textMode = new Text("Mode Student");
		Font myFont = new Font("certuty gothic", 50);
		textMode.setFont(myFont);
		textMode.setFill(Color.GOLD);

		GridPane panetxt = new GridPane();
		panetxt.setAlignment(Pos.CENTER);
		panetxt.setHgap(10);
		panetxt.setVgap(10);

		TextField txtMode = new TextField();
		panetxt.add(txtMode, 0, 0);

		if (isGaza && isScience) {
			txtMode.setText(mode(gazaScience) + "");
		} else if (isGaza && !isScience) {
			txtMode.setText(mode(gazaLiterary) + "");

		} else if (isScience) {
			txtMode.setText(mode(westBankScience) + "");

		} else {
			txtMode.setText(mode(westBankLiterary) + "");

		}

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		custmize(btBack);

		vBoxMode.getChildren().addAll(textMode, panetxt, btBack);

		btBack.setOnAction(e -> options(stage));

		setBackground(vBoxMode);
		Scene sceneTopMode = new Scene(vBoxMode, 1200, 700);
		stage.setScene(sceneTopMode);
	}

	// This function is for calculating those above the specified grade , Time comp
	// >> O(n)
	private double mode(LinkedList<Tawjihi> list) {
		Node<Tawjihi> prev = null;
		Node<Tawjihi> curr = list.getFront();

		int count = 0;
		int maxCount = 0;
		double mostAVG = 0;

		while (curr != null) {
			if (prev != null && prev.getElement().getAverage() == curr.getElement().getAverage())
				count++;
			else {
				if (maxCount < count) {
					mostAVG = prev.getElement().getAverage();
					maxCount = count;
				}

				count = 0;
			}

			prev = curr;
			curr = curr.getNext();
		}
		if (maxCount < count) {
			mostAVG = prev.getElement().getAverage();
			maxCount = count;
		}

		return mostAVG;
	}

	public void percentageOfStudents(Stage stage) {
		VBox vBoxPercentage = new VBox(30);
		vBoxPercentage.setAlignment(Pos.CENTER);

		Text textPercentage = new Text("Percentage of Students Above a Grade");
		Font myFont = new Font("certuty gothic", 40);
		textPercentage.setFont(myFont);
		textPercentage.setFill(Color.GOLD);

		GridPane panetxt = new GridPane();
		panetxt.setAlignment(Pos.CENTER);
		panetxt.setHgap(10);
		panetxt.setVgap(10);

		Label lbGrade = new Label("Grade to calculate number above it:");
		lbGrade.setMinWidth(500);
		panetxt.add(lbGrade, 0, 0);
		setLabelColor(lbGrade);

		TextField gradeField = new TextField();
		panetxt.add(gradeField, 1, 0);

		Label lbAbvGrade = new Label("Number of students above grade :");
		panetxt.add(lbAbvGrade, 0, 1);
		setLabelColor(lbAbvGrade);

		TextField txtnumber = new TextField();
		panetxt.add(txtnumber, 1, 1);

		Label percentageLabel = new Label("Percentage of students above grade :");
		panetxt.add(percentageLabel, 0, 2);
		setLabelColor(percentageLabel);

		TextField percentageField = new TextField();
		panetxt.add(percentageField, 1, 2);

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		custmize(btBack);

		Button btcalculation = new Button("Calculate Percentage");
		btcalculation.setMinSize(150, 80);
		custmize(btcalculation);
		btcalculation.setFont(new Font(25));
		vBoxPercentage.getChildren().addAll(textPercentage, panetxt, btcalculation, btBack);

		btcalculation.setOnAction(e -> {
			LinkedList<Tawjihi> list;
			try {
				if (isGaza && isScience) {
					list = studentsAbove(gazaScience, Double.parseDouble(gradeField.getText()));
					int length = list.length();
					txtnumber.setText(length + "");
					percentageField.setText((double) length / gazaScience.length() + "");

				} else if (isGaza && !isScience) {
					list = studentsAbove(gazaLiterary, Double.parseDouble(gradeField.getText()));
					int length = list.length();
					txtnumber.setText(length + "");
					percentageField.setText((double) length / gazaLiterary.length() + "");

				} else if (isScience) {
					list = studentsAbove(westBankScience, Double.parseDouble(gradeField.getText()));
					int length = list.length();
					txtnumber.setText(length + "");
					percentageField.setText((double) length / westBankScience.length() + "");

				} else {
					list = studentsAbove(westBankLiterary, Double.parseDouble(gradeField.getText()));
					int length = list.length();
					txtnumber.setText(length + "");
					percentageField.setText((double) length / westBankLiterary.length() + "");

				}
			} catch (NumberFormatException e1) {
				error.setContentText("You must Integer and double!!!!!");
				error.show();
			}

		});

		btBack.setOnAction(e ->

		options(stage));

		setBackground(vBoxPercentage);
		Scene sceneTopPercentage = new Scene(vBoxPercentage, 1200, 700);
		stage.setScene(sceneTopPercentage);
	}

	private LinkedList<Tawjihi> studentsAbove(LinkedList<Tawjihi> list, double d) {
		Node<Tawjihi> current = list.getFront();
		LinkedList<Tawjihi> l = new LinkedList<>();

		for (; current != null && current.getElement().getAverage() > d; current = current.getNext())
			l.addFirst(current.getElement());
		;

		return l;

	}

	public void searchStudent(Stage stage) {
		GridPane paneSearchStudent = new GridPane();

		paneSearchStudent.setAlignment(Pos.CENTER);
		paneSearchStudent.setHgap(20);
		paneSearchStudent.setVgap(20);

		Label lbSeat = new Label("Seat Number:");
		paneSearchStudent.add(lbSeat, 0, 0);
		setLabelColor(lbSeat);

		TextField txtSeat = new TextField();
		paneSearchStudent.add(txtSeat, 1, 0);
		textFieldCustom(txtSeat);

		Label lbAverage = new Label("Average:");
		paneSearchStudent.add(lbAverage, 0, 1);
		setLabelColor(lbAverage);

		TextField txtAverage = new TextField();
		txtAverage.setEditable(false);
		txtAverage.setPromptText("The AVG will be shown here");
		paneSearchStudent.add(txtAverage, 1, 1);
		textFieldCustom(txtAverage);

		Button btSearch = new Button("Search");
		btSearch.setMinSize(80, 40);
		btSearch.setFont(new Font(20));
		paneSearchStudent.add(btSearch, 1, 3);
		custmize(btSearch);

		btSearch.setOnAction(e -> {
			try {
				if (isGaza && isScience) {
					Node<Tawjihi> found = gazaScience
							.search(new Tawjihi(Integer.parseInt(txtSeat.getText()), STYLESHEET_CASPIAN, 0));
					if (found != null)
						txtAverage.setText(found.getElement().getAverage() + "");
					else {
						error.setContentText("Seat Number does NOT exist.");
						error.show();
					}

				} else if (isGaza && !isScience) {
					Node<Tawjihi> found = gazaLiterary
							.search(new Tawjihi(Integer.parseInt(txtSeat.getText()), STYLESHEET_CASPIAN, 0));
					if (found != null)
						txtAverage.setText(found.getElement().getAverage() + "");
					else {
						error.setContentText("Seat Number does NOT exist.");
						error.show();
					}

				} else if (isScience) {
					Node<Tawjihi> found = westBankScience
							.search(new Tawjihi(Integer.parseInt(txtSeat.getText()), STYLESHEET_CASPIAN, 0));
					if (found != null)
						txtAverage.setText(found.getElement().getAverage() + "");
					else {
						error.setContentText("Seat Number does NOT exist.");
						error.show();
					}
				} else {
					Node<Tawjihi> found = westBankLiterary
							.search(new Tawjihi(Integer.parseInt(txtSeat.getText()), STYLESHEET_CASPIAN, 0));
					if (found != null)
						txtAverage.setText(found.getElement().getAverage() + "");
					else {
						error.setContentText("Seat Number does NOT exist.");
						error.show();
					}
				}
			} catch (NumberFormatException e1) {
				error.setContentText("You must Integer and double!!!!!");
				error.show();
			}

		});

		Button btBack = new Button("Back");
		btBack.setMinSize(80, 40);
		btBack.setFont(new Font(20));
		paneSearchStudent.add(btBack, 0, 3);
		custmize(btBack);

		GridPane.setHalignment(btSearch, HPos.RIGHT);
		GridPane.setHalignment(btBack, HPos.CENTER);
		setBackground(paneSearchStudent);
		Scene sceneSearchStudent = new Scene(paneSearchStudent, 1200, 700);
		stage.setScene(sceneSearchStudent);

		btBack.setOnAction(e -> {
			options(stage);
		});

	}

	private void custmize(Button button) {
		button.setStyle("-fx-background-radius: 45;" + "-fx-color: black");
		button.setTextFill(Color.rgb(212, 155, 40));
	}

	private void textFieldCustom(TextField txtField) {
		txtField.setStyle(
				"-fx-control-inner-background: black;" + "-fx-text-fill: rgb(212, 155, 40);-fx-prompt-text-fill: gray");
		txtField.setMinSize(200, 40);
		txtField.setAlignment(Pos.CENTER);
		txtField.setFont(new Font("certuty gothic", 14));
	}

	private void setLabelColor(Label text) {
		text.setTextFill(Color.rgb(212, 155, 40));
		text.setMinSize(80, 40);
		text.setFont(new Font("certuty gothic", 20));
	}

	private void setBackground(Pane paneFace) {
		paneFace.setBackground(new Background(new BackgroundImage(new Image("bacground.jpg"), null, null, null, null)));
	}
	

	public static void main(String[] args) {

		launch(args);
	}
}
