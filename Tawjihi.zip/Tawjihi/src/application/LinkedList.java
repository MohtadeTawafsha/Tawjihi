package application;

public class LinkedList<Object extends Comparable<Object>> {
	private Node<Object> front;

	public Node<Object> getFront() {
		return front;
	}
	//This function is to arrange the first ten students, taking into account the repetition
	//Time Comp >> O(n) 
	public static LinkedList<Tawjihi> top10(LinkedList<Tawjihi> list) {
		Node<Tawjihi> prev = null;
		Node<Tawjihi> curr = list.getFront();
		LinkedList<Tawjihi> l = new LinkedList<>();
		//The LinkedList to memorize the first ten, taking into account the duplicates

		int count = 1;
		//To store each iteration value
		while (count < 10 && curr != null) {
			if (prev != null && prev.getElement().getAverage() != curr.getElement().getAverage())
				//while use to the first value is taken and compared with the next value
				count++;

			l.addLast(curr.getElement());
			//In order of order from largest to smallest
			prev = curr;
			curr = curr.getNext();
		}

		return l;

	}
	//This function in order to add to the first , Time Comp is constant 
	public void addFirst(Object d) {
		Node<Object> newNode = new Node<>(d);
		if (front == null)
			front = newNode;
		else {
			newNode.setNext(front);
			front = newNode;
		}

	}
	//This function in order to add to the Last , Time Comp O(n)
	public void addLast(Object d) {
		Node<Object> newNode = new Node<>(d);
		Node<Object> curr = front;
		if (front == null)
			front = newNode;
		else {
			while (curr.getNext() != null)
				curr = curr.getNext();
			curr.setNext(newNode);
		}

	}
	//This function is for calling the function from anywhere
	public int length() {
		return length(front);
	}
	//This function is for calculating its length to LinkedList , Time Comp >> O(n) 
	private int length(Node<Object> curr) {
		if (curr == null)
			return 0;

		return 1 + length(curr.getNext());
	}
	//This function is to search student by seat number
	public Node<Object> search(Object data) {
		Node<Object> curr = front;
		while (curr != null) {
			if (curr.getElement().equals(data))
				return curr;
			//if Existing return else continues
			curr = curr.getNext();
		}
		return curr;
	}
	//This function is to deleted any students by seat number , Time Comp >> O(n) 
	public boolean remove(Object data) {
		Node<Object> prev = null, curr = front;

		for (; curr != null && !curr.getElement().equals(data); prev = curr, curr = curr.getNext())
			;
		//The for loop calling equals to compare the student or not
		if (curr == null || front == null)
			return false;
		else if (prev == null) {
			front = curr.getNext();
			return true;
		} else {
			prev.setNext(curr.getNext());
			return true;
		}

	}
	//This function is for sorted student , Time Comp >> O(n) 
	public void addSort(Object d) {
		Node<Object> newNode = new Node<>(d);
		Node<Object> current = front, prev = null;

		for (; current != null && current.getElement().compareTo(d) < 0; prev = current, current = current.getNext())
			;
		//The for loop calling compareTo to compare according to average  
		if (front == null || prev == null)
			addFirst(d);
		else {
			newNode.setNext(current);
			prev.setNext(newNode);
		}
	}
	//For printing , Time Comp >> O(n) 
	@Override
	public String toString() {
		Node<Object> current = front;
		String s = "";
		while (current != null) {
			s += current.getElement() + "\n";
			current = current.getNext();
		}
		return s;
	}

}
