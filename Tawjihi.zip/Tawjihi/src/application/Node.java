package application;

public class Node<Object extends Comparable<Object>> {

	private Object element;
	private Node<Object> next;

	public Node(Object element) {
		this(element, null);
	}

	public Node(Object element, Node<Object> next) {
		this.setElement(element);
		this.setNext(next);
	}

	public Node<Object> getNext() {
		return next;
	}

	public void setNext(Node<Object> next) {
		this.next = next;
	}

	public Object getElement() {
		return element;
	}

	public void setElement(Object element) {
		this.element = element;
	}

	@Override
	public String toString() {
		return element.toString();
	}

}
