package application;

public class Tawjihi implements Comparable<Tawjihi> {
	private int seatNumber;
	private String branch;
	private double average;

	public Tawjihi() {
		super();
	}

	public Tawjihi(int seatNumber, String branch, double average) {
		super();
		this.seatNumber = seatNumber;
		this.branch = branch;
		this.average = average;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public double getAverage() {
		return average;
	}

	public void setAverage(double average) {
		this.average = average;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Tawjihi [seatNumber=" + seatNumber + ", average=" + average + ", branch=" + branch + "]\n";
	}
	
	@Override
	public int compareTo(Tawjihi o) {
		if (this.average > o.average)
			return -1;
		else if (this.average < o.average)
			return 1;
		else
			return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Tawjihi)
			return ((Tawjihi) obj).getSeatNumber() == this.getSeatNumber();
		return super.equals(obj);
	}

}
